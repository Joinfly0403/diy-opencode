#!/usr/bin/env python3
"""cogagent HUD broker.

职责（只做这三件事）：
  1. 驱动 cogagent 的 SSO 登录（无 TTY），拿到 cogagent 账号
  2. 按 cogagent 账号启动/复用 serve 实例，读取其凭据
  3. 发放 handle，并把前端请求代理到对应实例

不做什么：不存会话、不碰 OSSDIY 数据、不读 X-User-Name。
"""

import argparse
import base64
import json
import os
import re
import secrets
import threading  # MACRO_API_V1
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import zlib
from http.client import HTTPConnection
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

URL_RE = re.compile(r"^https://\S*oauth2/authorize\S*$")
ACCOUNT_RE = re.compile(r"^COGAGENT_LOGIN_ACCOUNT=(\S+)$")
LISTEN_RE = re.compile(r"server listening on http://127\.0\.0\.1:(\d+)")

STATE_LOCK = threading.RLock()
TICKETS = {}
HANDLES = {}
MACRO_RUNS = {}          # runId -> {"record":..., "event": threading.Event()}
MACRO_PENDING = {}       # account -> [cmd, ...]
MACRO_LOCK = threading.Lock()
MACRO_WEBUSER = {}       # WEB_OWNER_V1：cogagent 账号 -> 网页登录账户
try:
    import macro_store
    MACRO_STORE = None   # 在 Server.__init__ 里初始化
except Exception:
    macro_store = None
    MACRO_STORE = None
INSTANCES = {}


def log(msg):
    sys.stderr.write(time.strftime("[%H:%M:%S] ") + msg + "\n")
    sys.stderr.flush()


def account_port(account):
    return 41000 + (zlib.crc32(account.encode("utf-8")) % 20000)


def credential(root_base, account):
    path = os.path.join(root_base, account, "state", "cogagent", "service-local.json")
    try:
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, ValueError):
        return None
    password = data.get("password") or ""
    url = data.get("url") or ""
    port = None
    if url:
        try:
            port = int(urlparse(url).port or 0) or None
        except ValueError:
            port = None
    if not password:
        return None
    return {"password": password, "port": port or account_port(account)}


def basic(password):
    raw = ("opencode:" + password).encode("utf-8")
    return "Basic " + base64.b64encode(raw).decode("ascii")


def upstream_get(base, path, password, timeout=15):
    req = urllib.request.Request(base + path, method="GET")
    req.add_header("Authorization", basic(password))
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.status, resp.read()


class Server:
    def __init__(self, args):
        self.args = args
        self.root_base = args.root
        self.state_dir = args.state_dir
        os.makedirs(self.state_dir, exist_ok=True)
        self.handles_path = os.path.join(self.state_dir, "handles.json")
        self._load_handles()
        global MACRO_STORE
        if macro_store is not None and MACRO_STORE is None:
            MACRO_STORE = macro_store.Store(self.state_dir)

    def _load_handles(self):
        try:
            with open(self.handles_path, encoding="utf-8") as fh:
                data = json.load(fh)
            HANDLES.update(data.get("handles") or {})
        except (OSError, ValueError):
            pass

    def _save_handles(self):
        tmp = self.handles_path + ".tmp"
        payload = json.dumps({"handles": HANDLES}, ensure_ascii=False)
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(payload)
        os.replace(tmp, self.handles_path)

    def instance(self, account):
        entry = INSTANCES.get(account)
        if not entry:
            return None
        proc = entry.get("proc")
        if proc is not None and proc.poll() is not None:
            log("instance for %s exited with %s" % (account, proc.returncode))
            entry["state"] = "exited"
        return entry

    def ensure_instance(self, account):
        entry = self.instance(account)
        if entry and entry.get("state") == "ready":
            cred = credential(self.root_base, account)
            if cred and self.probe(cred["port"], cred["password"]):
                return entry
        cred = credential(self.root_base, account)
        if cred and self.probe(cred["port"], cred["password"]):
            entry = {"account": account, "port": cred["port"], "state": "ready", "proc": None}
            INSTANCES[account] = entry
            return entry
        return None

    def probe(self, port, password, timeout=4):
        try:
            status, _ = upstream_get("http://127.0.0.1:%d" % port, "/api/session", password, timeout)
            return status == 200
        except Exception:
            return False

    def start_login(self):
        now = time.time()   # LOGIN_RESET_V1：先清理卡住的旧票据
        for _tk, _e in list(TICKETS.items()):
            if _e.get("state") not in ("pending", "serving"):
                continue
            _p = _e.get("proc")
            _dead = _p is not None and _p.poll() is not None
            _expired = now > (_e.get("deadline") or 0)
            if _dead or _expired:
                try:
                    if _p is not None and _p.poll() is None:
                        _p.terminate()
                except Exception:
                    pass
                _e["state"] = "failed"
                _e["reason"] = "登录超时" if _expired else "登录进程已退出"
                log("ticket %s auto-cleaned (%s)" % (_tk, _e["reason"]))
        if any(t.get("state") in ("pending", "serving") for t in TICKETS.values()):
            return None, "另一个登录正在进行"
        ticket = secrets.token_urlsafe(16)
        env = dict(os.environ)
        env["COGAGENT_SERVE_ONLY"] = "1"
        env.pop("COGAGENT_NO_SANDBOX", None)
        proc = subprocess.Popen(
            [self.args.launcher],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            env=env,
            text=True,
            bufsize=1,
        )
        entry = {
            "state": "pending",
            "proc": proc,
            "url": None,
            "account": None,
            "port": None,
            "reason": None,
            "created": time.time(),
            "deadline": time.time() + self.args.login_timeout,
        }
        with STATE_LOCK:
            TICKETS[ticket] = entry
        threading.Thread(target=self._pump, args=(ticket, entry), daemon=True).start()
        return ticket, None

    def _pump(self, ticket, entry):
        proc = entry["proc"]
        try:
            for line in proc.stdout:
                line = line.rstrip("\n")
                m = URL_RE.match(line.strip())
                if m and not entry["url"]:
                    entry["url"] = line.strip()
                    log("ticket %s url captured" % ticket)
                    continue
                m = ACCOUNT_RE.match(line.strip())
                if m:
                    entry["account"] = m.group(1)
                    entry["state"] = "serving"
                    log("ticket %s account %s" % (ticket, m.group(1)))
                    reused = self.ensure_instance(entry["account"])
                    if reused:
                        entry["port"] = reused["port"]
                        log("ticket %s reuse existing instance on %d" % (ticket, reused["port"]))
                        try:
                            proc.terminate()
                        except Exception:
                            pass
                        self._finish(ticket, entry, proc=None)
                        return
                    threading.Thread(target=self._wait_ready, args=(ticket, entry), daemon=True).start()
                    continue
                m = LISTEN_RE.search(line)
                if m:
                    entry["port"] = int(m.group(1))
                    log("ticket %s listening on %s" % (ticket, m.group(1)))
                    self._finish(ticket, entry)
                    continue
            proc.wait(timeout=5)
        except Exception as exc:
            log("pump error for %s: %s" % (ticket, exc))
        if entry["state"] in ("pending", "serving"):
            entry["state"] = "failed"
            entry["reason"] = "登录进程已退出"

    def _wait_ready(self, ticket, entry):   # WAIT_READY_V1
        """serve-only 不一定打印 listening 行：主动探测 service-local.json + HTTP。"""
        account = entry.get("account")
        deadline = time.time() + 150
        while time.time() < deadline:
            if entry.get("state") not in ("pending", "serving") or entry.get("handle"):
                return
            cred = credential(self.root_base, account)
            if cred and self.probe(cred["port"], cred["password"]):
                entry["port"] = cred["port"]
                log("ticket %s ready via probe (port %d)" % (ticket, cred["port"]))
                self._finish(ticket, entry)
                return
            time.sleep(1)
        log("ticket %s wait_ready timeout" % ticket)

    def _finish(self, ticket, entry, proc="keep"):
        if entry.get("handle"):   # WAIT_READY_V1
            return
        account = entry["account"]
        port = entry["port"]
        cred = None
        for _ in range(20):
            cred = credential(self.root_base, account)
            if cred and self.probe(port, cred["password"]):
                break
            time.sleep(0.5)
        if not cred:
            entry["state"] = "failed"
            entry["reason"] = "读不到 service-local.json"
            return
        handle = secrets.token_urlsafe(32)
        with STATE_LOCK:
            HANDLES[handle] = {"account": account, "port": port, "created": time.time()}
            if (INSTANCES.get(account) or {}).get("state") != "ready":
                INSTANCES[account] = {"account": account, "port": port, "state": "ready",
                                      "proc": entry["proc"] if proc == "keep" else proc}
            entry["handle"] = handle
            entry["state"] = "ready"
            self._save_handles()
        log("ticket %s ready, account=%s port=%d" % (ticket, account, port))

    def resolve(self, handle):
        info = HANDLES.get(handle)
        if not info:
            return None
        cred = credential(self.root_base, info["account"])
        if not cred:
            return None
        try:  # HANDLE_LIVE_V1：端口不通说明实例已死，handle 视为无效
            import socket as _socket
            _c = _socket.create_connection(("127.0.0.1", cred["port"]), timeout=0.5)
            _c.close()
        except Exception:
            log("handle %s -> account %s port %d dead" % (handle[:8], info["account"], cred["port"]))
            return None
        return {"account": info["account"], "port": cred["port"], "password": cred["password"]}


class Handler(BaseHTTPRequestHandler):
    server_version = "cogagent-hud-broker/1.0"
    protocol_version = "HTTP/1.1"

    @property
    def app(self):
        return self.server.app

    def log_message(self, fmt, *args):
        log("http %s - %s" % (self.address_string(), fmt % args))

    def body(self):
        length = int(self.headers.get("Content-Length") or 0)
        if not length:
            return {}
        try:
            return json.loads(self.rfile.read(length).decode("utf-8"))
        except ValueError:
            return {}

    def send_json(self, code, payload):
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def require_handle(self):
        handle = self.headers.get("X-Hud-Handle") or ""
        if not handle:
            handle = (parse_qs(urlparse(self.path).query).get("handle") or [""])[0]
        info = self.app.resolve(handle)
        if not info:
            self.send_json(401, {"error": "handle_invalid"})
            return None, None
        return handle, info

    def require_owner(self):
        # WEB_OWNER_V1：网页登录账户优先（桥从 X-User-Name 透传）
        web = (self.headers.get("X-Hud-Web-User") or "").strip()
        acct = (self.headers.get("X-Hud-Account") or "").strip()
        host = self.client_address[0] if self.client_address else ""
        local = host in ("127.0.0.1", "::1", "::ffff:127.0.0.1")
        if web and local:
            if acct:
                with MACRO_LOCK:
                    MACRO_WEBUSER[acct] = web
            return web
        if acct and local:
            with MACRO_LOCK:
                return MACRO_WEBUSER.get(acct, acct)
        handle, info = self.require_handle()
        if not info:
            return None
        with MACRO_LOCK:
            return MACRO_WEBUSER.get(info["account"], info["account"])

    def _pins_path(self):
        return os.path.join(self.state_dir, "pins.json")

    def _load_pins(self):
        try:
            with open(self._pins_path(), encoding="utf-8") as fh:
                return json.load(fh)
        except (OSError, ValueError):
            return {}

    def _save_pins(self, data):
        os.makedirs(self.state_dir, mode=0o750, exist_ok=True)
        tmp = self._pins_path() + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, indent=1)
        os.replace(tmp, self._pins_path())

    def macro_ready(self):
        if MACRO_STORE is None:
            self.send_json(503, {"error": "macro_unavailable", "detail": "macro_store 未加载"})
            return False
        return True

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        if path == "/status":
            with STATE_LOCK:
                items = [
                    {"account": i["account"], "port": i["port"], "state": i["state"]}
                    for i in INSTANCES.values()
                ]
            self.send_json(200, {"instances": items, "count": len(items)})
            return
        if path == "/login/active":   # LOGIN_RESET_V1
            items = []
            for _tk, _e in list(TICKETS.items()):
                items.append({"ticket": _tk[:8], "state": _e.get("state"), "account": _e.get("account"),
                              "reason": _e.get("reason"), "age": int(time.time() - (_e.get("created") or 0))})
            self.send_json(200, {"count": len(items), "tickets": items})
            return
        if path == "/login/status":
            ticket = (parse_qs(parsed.query).get("ticket") or [""])[0]
            entry = TICKETS.get(ticket)
            if not entry:
                self.send_json(404, {"error": "ticket_not_found"})
                return
            if entry["state"] in ("pending", "serving") and time.time() > entry["deadline"]:
                entry["state"] = "failed"
                entry["reason"] = "登录超时"
                try:
                    entry["proc"].terminate()
                except Exception:
                    pass
            payload = {"state": entry["state"]}
            for key in ("url", "account", "handle", "reason"):
                if entry.get(key):
                    payload[key] = entry[key]
            self.send_json(200, payload)
            return
        if path == "/agent/macro/pending" and self.macro_ready():
            owner = self.require_owner()
            if not owner:
                return
            with MACRO_LOCK:
                cmds = MACRO_PENDING.pop(owner, [])
            self.send_json(200, {"commands": cmds})
            return
        if path == "/agent/macro/list" and self.macro_ready():
            owner = self.require_owner()
            if not owner:
                return
            q = parse_qs(parsed.query)
            scope = (q.get("scope") or ["all"])[0]
            query = (q.get("q") or [""])[0]
            self.send_json(200, {"macros": MACRO_STORE.list(owner, scope, query)})
            return
        if path == "/agent/macro/get" and self.macro_ready():
            owner = self.require_owner()
            if not owner:
                return
            mid = (parse_qs(parsed.query).get("id") or [""])[0]
            try:
                macro = MACRO_STORE.get(owner, mid)
            except macro_store.MacroError as exc:
                self.send_json(404 if exc.code == "macro_not_found" else 403, {"error": exc.code, "detail": exc.detail})
                return
            self.send_json(200, {"macro": macro})
            return
        if path == "/agent/macro/pin" and self.macro_ready():   # PIN_V1
            owner = self.require_owner()
            if not owner:
                return
            sig = (parse_qs(parsed.query).get("sig") or [""])[0]
            data = self._load_pins()
            mine = data.get(owner) or {}
            if not sig:
                self.send_json(200, {"pins": mine})
                return
            self.send_json(200, {"sig": sig, "pin": mine.get(sig)})
            return
        if path == "/agent/macro/runs" and self.macro_ready():
            owner = self.require_owner()
            if not owner:
                return
            q = parse_qs(parsed.query)
            mid = (q.get("id") or [None])[0]
            limit = int((q.get("limit") or ["20"])[0])
            self.send_json(200, {"runs": MACRO_STORE.list_runs(owner, mid, limit)})
            return
        if path.startswith("/agent/"):
            handle, info = self.require_handle()
            if not info:
                return
            self.proxy(path, info, parsed)
            return
        self.send_json(404, {"error": "not_found"})
    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        if path == "/agent/macro/save" and self.macro_ready():
            owner = self.require_owner()
            if not owner:
                return
            body = self.body()
            try:
                res = MACRO_STORE.save(owner, body.get("macro") or {}, body.get("mode", "upsert"), actor=owner)
            except macro_store.MacroError as exc:
                code = 409 if exc.code == "macro_conflict" else 400
                self.send_json(code, {"error": exc.code, "detail": exc.detail})
                return
            self.send_json(200, res)
            return
        if path == "/agent/macro/delete" and self.macro_ready():
            owner = self.require_owner()
            if not owner:
                return
            body = self.body()
            try:
                res = MACRO_STORE.delete(owner, body.get("id") or "", bool(body.get("hard")), actor=owner)
            except macro_store.MacroError as exc:
                self.send_json(404 if exc.code == "macro_not_found" else 403, {"error": exc.code})
                return
            self.send_json(200, res)
            return
        if path == "/agent/macro/run" and self.macro_ready():
            owner = self.require_owner()
            if not owner:
                return
            body = self.body()
            mid = body.get("id") or ""
            try:
                macro = MACRO_STORE.get(owner, mid)
            except macro_store.MacroError as exc:
                self.send_json(404, {"error": exc.code})
                return
            with MACRO_LOCK:
                now = time.time()
                for rid0, r0 in list(MACRO_RUNS.items()):   # STALE_RUN_V1：页面刷新/断线后自动释放
                    rec0 = r0.get("record") or {}
                    if rec0.get("result") != "running":
                        continue
                    touched = r0.get("touched") or r0.get("started") or now
                    if now - touched < 20:   # STALE_RUN_V1
                        continue
                    rec0["result"] = "failed"
                    rec0["failedStep"] = None
                    rec0["endedAt"] = time.strftime("%Y-%m-%dT%H:%M:%S%z")
                    rec0["stale"] = True
                    try:
                        MACRO_STORE.append_run(r0.get("owner") or owner, rec0)   # STALE_OWNER_V1
                    except Exception:
                        pass
                    try:
                        r0["event"].set()
                    except Exception:
                        pass
                    MACRO_RUNS.pop(rid0, None)
                    log("macro run stale released: %s" % rid0)
                if any(r.get("owner") == owner and r["record"].get("result") == "running" for r in MACRO_RUNS.values()):
                    self.send_json(409, {"error": "macro_busy"})
                    return
                rec = MACRO_STORE.start_run(owner, mid, macro.get("version", 0), body.get("params") or {}, body.get("trigger", "user"))
                ev = threading.Event()
                MACRO_RUNS[rec["runId"]] = {"owner": owner, "record": rec, "event": ev,
                                            "started": time.time(), "touched": time.time()}
                MACRO_PENDING.setdefault(owner, []).append({
                    "runId": rec["runId"], "macro": macro, "params": body.get("params") or {},
                    "count": int(body.get("count", 1)), "sessionID": body.get("sessionID"),
                    "slowMode": bool(body.get("slowMode", True)),
                    "deadline": time.time() + int(body.get("timeout", 120)),
                })
            if body.get("wait"):
                done = ev.wait(timeout=int(body.get("timeout", 120)))
                final = MACRO_RUNS[rec["runId"]]["record"]
                self.send_json(200 if done else 504, {"runId": rec["runId"], "done": done, "run": final})
                return
            self.send_json(200, {"runId": rec["runId"], "accepted": True})
            return
        if path == "/agent/macro/pin" and self.macro_ready():   # PIN_V1
            owner = self.require_owner()
            if not owner:
                return
            body = self.body()
            sig = (body.get("sig") or "").strip()
            if not sig:
                self.send_json(400, {"error": "sig_required"})
                return
            data = self._load_pins()
            mine = data.setdefault(owner, {})
            pin = body.get("pin")
            if pin is None:
                mine.pop(sig, None)
            else:
                pin["updatedAt"] = time.strftime("%Y-%m-%dT%H:%M:%S%z")
                mine[sig] = pin
            data[owner] = mine
            self._save_pins(data)
            self.send_json(200, {"ok": True, "sig": sig})
            return
        if path == "/agent/macro/cancel" and self.macro_ready():   # CANCEL_V1
            owner = self.require_owner()
            if not owner:
                return
            body = self.body() if self.command == "POST" else {}
            rid = body.get("runId") or ""
            note = body.get("note") or "unspecified"
            only_stale = bool(body.get("onlyStale"))
            min_idle = float(body.get("minIdle") or 0)
            now_ts = time.time()
            log("macro cancel requested: note=%s runId=%s" % (note, rid or "-"))
            released = []
            with MACRO_LOCK:
                for k, r in list(MACRO_RUNS.items()):
                    if r.get("owner") != owner:
                        continue
                    if rid and k != rid:
                        continue
                    rec = r.get("record") or {}
                    if only_stale:
                        touched = r.get("touched") or r.get("started") or 0
                        if now_ts - touched < min_idle:
                            continue
                    if rec.get("result") == "running":
                        rec["result"] = "cancelled"
                        rec["cancelNote"] = note
                        rec["endedAt"] = time.strftime("%Y-%m-%dT%H:%M:%S%z")
                        try:
                            MACRO_STORE.append_run(owner, rec)
                        except Exception:
                            pass
                    try:
                        r["event"].set()
                    except Exception:
                        pass
                    MACRO_RUNS.pop(k, None)
                    released.append(k)
                if rid:
                    left = [c for c in (MACRO_PENDING.get(owner) or []) if c.get("runId") != rid]
                    MACRO_PENDING[owner] = left   # CANCEL_SCOPE_V1
                else:
                    MACRO_PENDING.pop(owner, None)
            self.send_json(200, {"cancelled": released})
            return
        if path == "/agent/macro/result" and self.macro_ready():
            owner = self.require_owner()
            if not owner:
                return
            body = self.body()
            rid = body.get("runId") or ""
            with MACRO_LOCK:
                entry = MACRO_RUNS.get(rid)
            if not entry:
                self.send_json(404, {"error": "run_not_found"})
                return
            if entry.get("owner") != owner:   # RUN_OWNER_V1
                self.send_json(403, {"error": "run_forbidden"})
                return
            rec = entry["record"]
            entry["touched"] = time.time()   # STALE_RUN_V1
            if body.get("step") is not None:
                step_rec = {
                    "index": body.get("step"), "action": body.get("action"),
                    "ok": bool(body.get("ok")), "ms": body.get("ms"),
                    "via": body.get("via", "ui"), "error": body.get("error"),
                }
                for extra_key in ("method", "endpoint", "req", "res"):
                    if body.get(extra_key):
                        step_rec[extra_key] = body.get(extra_key)
                rec.setdefault("steps", []).append(step_rec)
                if (body.get("action") == "api") or body.get("req") or body.get("res"):
                    try:   # API_LOG_V1：每次接口调用单独落一行（入参 + 返回值）
                        MACRO_STORE.append_api(owner, {
                            "runId": rid,
                            "macroId": rec.get("macroId"),
                            "index": body.get("step"),
                            "method": body.get("method"),
                            "endpoint": body.get("endpoint"),
                            "ok": bool(body.get("ok")),
                            "req": body.get("req"),
                            "res": body.get("res"),
                            "error": body.get("error"),
                        })
                    except Exception as exc:
                        log("append_api failed: %r" % (exc,))
            if body.get("outputs"):
                rec.setdefault("outputs", {}).update(body["outputs"])
            if body.get("via") == "api":
                rec["fallbackUsed"] = True
            if body.get("final"):
                rec["result"] = body.get("result", "ok")
                rec["failedStep"] = body.get("failedStep")
                rec["endedAt"] = time.strftime("%Y-%m-%dT%H:%M:%S%z")
                MACRO_STORE.append_run(owner, rec)
                entry["event"].set()
            self.send_json(200, {"ok": True})
            return

        if path == "/login/start":
            ticket, error = self.app.start_login()
            if error:
                self.send_json(503, {"error": error})
                return
            entry = TICKETS[ticket]
            for _ in range(100):
                if entry.get("url"):
                    break
                time.sleep(0.1)
            self.send_json(200, {"ticket": ticket, "url": entry.get("url"), "expiresIn": self.app.args.login_timeout})
            return
        if path == "/login/cancel":
            ticket = (self.body().get("ticket") or "")
            entry = TICKETS.get(ticket)
            if not entry:
                self.send_json(404, {"error": "ticket_not_found"})
                return
            try:
                entry["proc"].terminate()
            except Exception:
                pass
            entry["state"] = "failed"
            entry["reason"] = "已取消"
            self.send_json(200, {"state": "idle"})
            return
        if path == "/login/reset":   # LOGIN_RESET_V1
            killed = 0
            for _tk, _e in list(TICKETS.items()):
                if _e.get("state") in ("pending", "serving"):
                    try:
                        _p = _e.get("proc")
                        if _p is not None and _p.poll() is None:
                            _p.terminate()
                    except Exception:
                        pass
                    _e["state"] = "failed"
                    _e["reason"] = "已重置"
                    killed += 1
            self.send_json(200, {"reset": killed})
            return
        if path == "/logout":
            handle = (self.body().get("handle") or self.headers.get("X-Hud-Handle") or "")
            with STATE_LOCK:
                HANDLES.pop(handle, None)
                self.app._save_handles()
            self.send_json(200, {"state": "idle"})
            return
        if path.startswith("/agent/"):
            handle, info = self.require_handle()
            if not info:
                return
            self.proxy(path, info, parsed)
            return
        self.send_json(404, {"error": "not_found"})

    def proxy(self, path, info, parsed):
        body = b""
        if self.command == "POST":
            length = int(self.headers.get("Content-Length") or 0)
            body = self.rfile.read(length) if length else b"{}"
        method = self.command
        if path == "/agent/session/delete":
            try:
                data = json.loads(body.decode("utf-8"))
            except ValueError:
                self.send_json(400, {"error": "bad_request"})
                return
            sid = data.get("sessionID")
            if not sid:
                self.send_json(400, {"error": "bad_request"})
                return
            method = "DELETE"
        if path == "/agent/events":
            self.stream_events(info)
            return
        if method == "DELETE":
            target, payload = "/api/session/%s" % sid, None
        elif path == "/agent/session/title":
            try:
                data = json.loads(body.decode("utf-8"))
            except ValueError:
                self.send_json(400, {"error": "bad_request"})
                return
            sid2 = data.get("sessionID")
            title = (data.get("title") or "").strip()
            if not sid2 or not title:
                self.send_json(400, {"error": "bad_request"})
                return
            method = "PATCH"
            target = "/api/session/%s" % sid2
            payload = json.dumps({"title": title}).encode("utf-8")
        elif path == "/agent/session/perms":
            q = parse_qs(parsed.query)
            sid = q.get("sessionID", [""])[0]
            if method == "POST":
                try:
                    data = json.loads(body.decode("utf-8"))
                except ValueError:
                    self.send_json(400, {"error": "bad_request"})
                    return
                sid = data.get("sessionID") or sid
                mode = data.get("mode") or "ask"
                rules = [{"action": "*", "resource": "*", "effect": "allow"}] if mode == "bypass" else []
                method = "PATCH"
                target = "/api/session/%s" % sid
                payload = json.dumps({"permissions": rules}).encode("utf-8")
            else:
                target, payload = "/api/session/%s" % sid, None
        else:
            target, payload = self.map_path(path, parsed, body)
        if target is None:
            self.send_json(400, {"error": "bad_request"})
            return
        req = urllib.request.Request(
            "http://127.0.0.1:%d%s" % (info["port"], target), data=payload, method=method
        )
        req.add_header("Authorization", basic(info["password"]))
        req.add_header("Content-Type", "application/json")
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                data = resp.read()
                status = resp.status
        except urllib.error.HTTPError as exc:
            data = exc.read()
            status = exc.code
        except Exception as exc:
            self.send_json(502, {"error": "upstream_failed", "detail": str(exc)})
            return
        if path == "/agent/models":  # MODEL_SANITIZE_V2（白名单，只放前端需要的字段）
            try:
                obj = json.loads(data.decode("utf-8"))
                safe = []
                for m in obj.get("data") or []:
                    if not isinstance(m, dict):
                        continue
                    safe.append({
                        "id": m.get("id"),
                        "providerID": m.get("providerID"),
                        "name": m.get("name") or m.get("id"),
                        "type": m.get("type") or "chat",
                        "enabled": m.get("enabled", True),
                        "status": m.get("status"),
                    })
                obj["data"] = safe
                data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
            except Exception:
                pass
        if status == 401:
            self.send_json(401, {"error": "upstream_unauthorized"})
            return
        if status == 204:  # NO204_V1：204 在部分网关/客户端上会变成 500
            status = 200
            data = b'{"ok":true}'
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def map_path(self, path, parsed, body):
        if path == "/agent/sessions":
            return "/api/session", None
        if path == "/agent/session":
            return "/api/session", body
        if path == "/agent/messages":
            q = parse_qs(parsed.query)
            session = (q.get("sessionID") or [""])[0]
            if not session:
                return None, None
            extra = []
            for k in ("order", "limit", "cursor"):
                if q.get(k):
                    extra.append("%s=%s" % (k, q[k][0]))
            suffix = ("?" + "&".join(extra)) if extra else ""
            return "/api/session/%s/message%s" % (session, suffix), None
        if path == "/agent/prompt":
            try:
                data = json.loads(body.decode("utf-8"))
            except ValueError:
                return None, None
            session = data.get("sessionID")
            if not session:
                return None, None
            return "/api/session/%s/prompt" % session, json.dumps({"text": data.get("text", "")}).encode("utf-8")
        if path == "/agent/reply":
            try:
                data = json.loads(body.decode("utf-8"))
            except ValueError:
                return None, None
            session = data.get("sessionID")
            request = data.get("requestID")
            if not session or not request:
                return None, None
            payload = {"decision": data.get("decision", "once")}
            if data.get("message"):
                payload["message"] = data["message"]
            return "/api/session/%s/permission/%s/reply" % (session, request), json.dumps(payload).encode("utf-8")
        if path == "/agent/switchAgent":
            try:
                data = json.loads(body.decode("utf-8"))
            except ValueError:
                return None, None
            session = data.get("sessionID")
            agent = data.get("agent")
            if not session or not agent:
                return None, None
            return "/api/session/%s/agent" % session, json.dumps({"agent": agent}).encode("utf-8")
        if path == "/agent/models":
            return "/api/model", None
        if path == "/agent/model":
            try:
                data = json.loads(body.decode("utf-8"))
            except ValueError:
                return None, None
            session = data.get("sessionID")
            model = data.get("model") or {}
            if not session or not model.get("providerID") or not model.get("id"):
                return None, None
            return "/api/session/%s/model" % session, json.dumps({"model": model}).encode("utf-8")
        if path == "/agent/permissions":
            return "/api/permission/request", None
        if path == "/agent/forms":
            session = (parse_qs(parsed.query).get("sessionID") or [""])[0]
            if not session:
                return None, None
            return "/api/session/%s/form" % session, None
        if path == "/agent/form/reply":
            try:
                data = json.loads(body.decode("utf-8"))
            except ValueError:
                return None, None
            session = data.get("sessionID")
            form = data.get("formID")
            if not session or not form:
                return None, None
            return "/api/session/%s/form/%s/reply" % (session, form), json.dumps({"answer": data.get("answer") or {}}).encode("utf-8")
        if path == "/agent/interrupt":
            try:
                data = json.loads(body.decode("utf-8"))
            except ValueError:
                return None, None
            session = data.get("sessionID")
            if not session:
                return None, None
            return "/api/session/%s/interrupt" % session, b"{}"
        return None, None

    def stream_events(self, info):
        conn = HTTPConnection("127.0.0.1", info["port"], timeout=None)
        try:
            conn.request("GET", "/api/event", headers={
                "Authorization": basic(info["password"]),
                "Accept": "text/event-stream",
            })
            upstream = conn.getresponse()
        except Exception as exc:
            self.send_json(502, {"error": "upstream_failed", "detail": str(exc)})
            return
        if upstream.status != 200:
            self.send_json(upstream.status, {"error": "upstream_status"})
            return
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Accel-Buffering", "no")
        self.send_header("Connection", "close")
        self.close_connection = True
        self.end_headers()
        last_ping = time.time()
        try:
            while True:
                chunk = upstream.read(1)
                if not chunk:
                    break
                self.wfile.write(chunk)
                self.wfile.flush()
                if time.time() - last_ping > 15:
                    self.wfile.write(b": ping\n\n")
                    self.wfile.flush()
                    last_ping = time.time()
        except Exception:
            pass
        finally:
            try:
                conn.close()
            except Exception:
                pass


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=18765)
    parser.add_argument("--hostname", default="127.0.0.1")
    parser.add_argument("--root", default="/srv/cogagent/users")
    parser.add_argument("--state-dir", default="/var/lib/cogagent-hud")
    parser.add_argument("--launcher", default="/usr/local/bin/cogagent")
    parser.add_argument("--login-timeout", type=int, default=300)
    args = parser.parse_args()

    app = Server(args)
    httpd = ThreadingHTTPServer((args.hostname, args.port), Handler)
    httpd.app = app
    httpd.daemon_threads = True
    log("broker listening on http://%s:%d" % (args.hostname, args.port))
    httpd.serve_forever()


if __name__ == "__main__":
    main()
